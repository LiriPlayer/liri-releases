// FFmpeg-Audio-Erweiterung (ersetzt org.jellyfin.media3:media3-ffmpeg-decoder, GPL-3.0):
// Java-Quellen + JNI-Hülle aus androidx/media 1.9.0 libraries/decoder_ffmpeg (Apache 2.0),
// FFmpeg 6.0.1 selbst gebaut als LGPL 2.1 (build_ffmpeg_windows.sh) → src/main/jniLibs/<abi>/libffmpegJNI.so.
plugins {
    id("com.android.library")
}

android {
    namespace = "androidx.media3.decoder.ffmpeg"
    compileSdk = 36
    defaultConfig {
        minSdk = 23
        consumerProguardFiles("proguard-rules.txt")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    val media3 = "1.9.0"
    api("androidx.media3:media3-decoder:$media3")
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.annotation:annotation:1.9.1")
    compileOnly("org.checkerframework:checker-qual:3.48.4")
}
