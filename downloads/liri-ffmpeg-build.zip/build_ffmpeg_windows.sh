#!/bin/bash
# Baut FFmpeg (LGPL, nur Audio-Decoder) und libffmpegJNI.so für alle vier Android-ABIs unter Windows (MSYS2-Bash + Windows-NDK).
# Ergebnis: ffmpeg/src/main/jniLibs/<abi>/libffmpegJNI.so (wird von Gradle ins APK gepackt).
#
# Aufruf (MSYS2-Bash, Pfade ohne Leerzeichen für FFmpeg):
#   build_ffmpeg_windows.sh <ffmpeg-quellcode> <ndk> <jniLibs-ziel>
# Beispiel:
#   build_ffmpeg_windows.sh ~/ffb/ffmpeg-6.0.1 ~/ffb/android-ndk-r26b ".../ffmpeg/src/main/jniLibs"
#
# Kein --enable-gpl / --enable-nonfree → FFmpeg bleibt LGPL 2.1.
set -eu

FFMPEG="$1"
NDK="$2"
OUT="$3"
JNI_SRC="$(cd "$(dirname "$0")" && pwd)/src/main/jni"
API=23   # = minSdk der App
TC="$NDK/toolchains/llvm/prebuilt/windows-x86_64/bin"
DECODERS="flac alac pcm_mulaw pcm_alaw mp3 aac ac3 eac3 dca mlp truehd"
JOBS="$(nproc 2>/dev/null || echo 4)"

OPTS="--target-os=android --enable-cross-compile --enable-static --disable-shared --disable-doc --disable-programs
  --disable-everything --disable-avdevice --disable-avformat --disable-swscale --disable-postproc --disable-avfilter
  --disable-symver --enable-swresample --disable-v4l2-m2m --disable-vulkan --disable-debug --enable-pic
  --cc=$TC/clang.exe --cxx=$TC/clang++.exe --ld=$TC/clang.exe
  --nm=$TC/llvm-nm.exe --ar=$TC/llvm-ar.exe --ranlib=$TC/llvm-ranlib.exe --strip=$TC/llvm-strip.exe"
for d in $DECODERS; do OPTS="$OPTS --enable-decoder=$d"; done

build() {   # abi arch cpu triple extra-configure extra-cflags
  local abi="$1" arch="$2" cpu="$3" triple="$4" extra="$5" cflags="$6"
  local prefix="$FFMPEG/android-libs/$abi"
  echo "=== $abi ==="
  cd "$FFMPEG"
  make distclean >/dev/null 2>&1 || true
  ./configure --prefix="$prefix" --libdir="$prefix/lib" --incdir="$prefix/include" --arch="$arch" --cpu="$cpu" \
    --extra-cflags="--target=$triple$API $cflags" --extra-ldflags="--target=$triple$API" $extra $OPTS
  make -j"$JOBS"
  make install-libs install-headers
  # JNI-Hülle (Apache 2.0, aus androidx/media decoder_ffmpeg) gegen die statischen FFmpeg-Bibliotheken linken
  mkdir -p "$OUT/$abi"
  local ldx=""
  [ "$abi" = "arm64-v8a" ] && ldx="-Wl,-Bsymbolic"
  "$TC/clang++.exe" --target=$triple$API -std=c++11 -O2 -fPIC -shared $cflags \
    -I"$prefix/include" "$JNI_SRC/ffmpeg_jni.cc" \
    "$prefix/lib/libswresample.a" "$prefix/lib/libavcodec.a" "$prefix/lib/libavutil.a" \
    -landroid -llog -lm -static-libstdc++ -Wl,-z,max-page-size=16384 -Wl,--gc-sections $ldx \
    -o "$OUT/$abi/libffmpegJNI.so"
  "$TC/llvm-strip.exe" --strip-unneeded "$OUT/$abi/libffmpegJNI.so"
  ls -la "$OUT/$abi/libffmpegJNI.so"
}

build armeabi-v7a arm    armv7-a armv7a-linux-androideabi "" "-march=armv7-a -mfloat-abi=softfp"
build arm64-v8a   aarch64 armv8-a aarch64-linux-android    "" ""
build x86         x86    i686    i686-linux-android        "--disable-asm" ""
build x86_64      x86_64 x86-64  x86_64-linux-android      "--disable-asm" ""
echo "FERTIG"
